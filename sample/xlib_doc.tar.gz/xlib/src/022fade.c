#include <X11/Xlib.h>
#include <X11/keysym.h>
#include <X11/Xutil.h>            /* shape.h ������ɬ�� */
#include <X11/extensions/shape.h> /* Shape Extension    */
#include <Imlib.h>
#include <stdio.h>
#include <string.h>
#include <sys/time.h>
#include <unistd.h>

static Display* display;
static Window window;
static ImlibData*  imlib_data;
static ImlibImage* imlib_image;
static Pixmap pixmap;
static Pixmap mask;
static unsigned char* original;
static int width;
static int height;


static int  save_original( void );
static void disable_resize( void );
static void render( void );
static void update_image( void );
static void show_original( void );
static void fade_in( void );
static void fade_out( void );


int
main( int argc, char** argv )
{
	int screen;

	if ( argc <= 1 ) {
		fprintf( stderr, "�����ե��������ꤷ�Ƥ���������\n" );
		exit(1);
	}

	display = XOpenDisplay( NULL );
	screen  = DefaultScreen( display );

	if ( ( imlib_data = Imlib_init( display ) ) == NULL ) {
		fprintf( stderr, "Imlib �ν�����˼��Ԥ��ޤ�����\n" );
		XCloseDisplay( display );
		exit(1);
	}

	if ( ( imlib_image = Imlib_load_image( imlib_data, argv[1] ) ) == NULL ) {
		fprintf( stderr, "�������ɤ߹��ߤ˼��Ԥ��ޤ�����\n" );
		XCloseDisplay( display );
		exit(1);
	}

	width  = imlib_image->rgb_width;
	height = imlib_image->rgb_height;

	if ( save_original() != 0 ) {
		fprintf( stderr, "����������¸�˼��Ԥ��ޤ�����\n" );
		Imlib_kill_image( imlib_data, imlib_image );
		XCloseDisplay( display );
		exit(1);
	}

	window = XCreateSimpleWindow( 
		display, 
		DefaultRootWindow( display ),
		width,
		height,
		width,
		height,
		0,
		BlackPixel( display, screen ),
		BlackPixel( display, screen ) 
		);

	disable_resize();
	XSelectInput( display, window, StructureNotifyMask | KeyPressMask );
	XMapWindow( display, window );
	render();
	update_image();

	while ( 1 ) {
		int esc_pressed = 0;
		XEvent event;
		KeySym key_sym;

		XNextEvent( display, &event );

		switch ( event.type ) {
			case KeyPress:
				XLookupString( &( event.xkey ), 
					NULL, 0, &key_sym, NULL );

				switch ( key_sym ) {
					case XK_Left:
					case XK_Right:
						show_original();
						break;

					case XK_Up:
						fade_in();
						break;

					case XK_Down:
						fade_out();
						break;

					case XK_Escape:
						esc_pressed = 1;
						break;
				}

				break;
		}

		if ( esc_pressed ) {
			break;
		}
	}

	Imlib_free_pixmap( imlib_data, pixmap );
	Imlib_kill_image( imlib_data, imlib_image );
	free( original );
	XDestroyWindow( display, window );
	XCloseDisplay( display );
	return 0;
}


static int
save_original( void )
{
	int size = width * height * 3;

	if ( ( original = ( unsigned char* )malloc( size ) ) == NULL ) {
		return -1;
	}

	memcpy( original, imlib_image->rgb_data, size );
	return 0;
}


static void
disable_resize( void )
{
	XSizeHints hints;

	hints.min_width  = width;
	hints.min_height = height;
	hints.max_width  = width;
	hints.max_height = height;
	hints.flags = PMinSize | PMaxSize;

	XSetWMNormalHints( display, window, &hints );
}


static void
render( void )
{
	Imlib_render( imlib_data, imlib_image, width, height );
	pixmap = Imlib_move_image( imlib_data, imlib_image );
	mask = Imlib_move_mask( imlib_data, imlib_image );
}


static void
update_image( void )
{
	XSetWindowBackgroundPixmap( display, window, pixmap );
	
	if ( mask ) {
		XShapeCombineMask( display, window, 
			ShapeBounding, 0, 0, mask, ShapeSet );
	}

	XClearWindow( display, window );
	XSync( display, False );
}


static void
show_original( void )
{
	memcpy( imlib_image->rgb_data, original, width * height * 3 );
	Imlib_free_pixmap( imlib_data, pixmap );
	Imlib_changed_image( imlib_data, imlib_image );
	render();
	update_image();
}


#define TIMER_DIFF( diff, end, start ) { \
	(diff)->tv_usec = (end)->tv_usec - (start)->tv_usec; \
	if ( (diff)->tv_usec < 0 ) {\
		(diff)->tv_usec += 1000000; \
		(diff)->tv_sec = (end)->tv_sec - (start)->tv_sec - 1;\
	}\
	else {\
		(diff)->tv_sec = (end)->tv_sec - (start)->tv_sec;\
	}\
	if ( (diff)->tv_sec < 0 ) {\
		(diff)->tv_sec = (diff)->tv_usec = 0;\
	}\
}

#define MIX_IMAGE( ratio ) { \
	int row;   \
	int col;   \
	int rgb;   \
	int index; \
\
	for ( row = 0; row < height; row ++ ) { \
		for ( col = 0; col < width; col ++ ) { \
			for ( rgb = 0; rgb < 3; rgb ++ ) { \
				index = ( row * width + col ) * 3 + rgb; \
				imlib_image->rgb_data[ index ] = ( unsigned char )\
				  ( original[ index ] * ( ratio ) / 100 ); \
			} \
		} \
	} \
\
	Imlib_free_pixmap( imlib_data, pixmap ); \
	Imlib_changed_image( imlib_data, imlib_image ); \
	render(); \
	update_image(); \
}


static void
fade_in( void )
{
	struct timeval start;
	struct timeval end;
	struct timeval diff;

	int ratio = 0;

	printf( "Fade in..." );
	fflush( stdout );
	gettimeofday( &start, NULL );

	while ( ratio < 100 ) {
		MIX_IMAGE( ratio );
		ratio += 2;
	}

	gettimeofday( &end, NULL );
	TIMER_DIFF( &diff, &end, &start );
	printf( "done ( %ld ).\n", diff.tv_sec * 1000000 + diff.tv_usec );
	fflush( stdout );
}


static void
fade_out( void )
{
	struct timeval start;
	struct timeval end;
	struct timeval diff;

	int ratio = 100;

	printf( "Fade out..." );
	fflush( stdout );
	gettimeofday( &start, NULL );

	while ( ratio > 0 ) {
		MIX_IMAGE( ratio );
		ratio -= 2;
	}

	gettimeofday( &end, NULL );
	TIMER_DIFF( &diff, &end, &start );
	printf( "done ( %ld ).\n", diff.tv_sec * 1000000 + diff.tv_usec );
	fflush( stdout );
}


/* End of fade.c */
