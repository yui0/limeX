#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <stdio.h>

int main(int argc ,char *argv[]){
    Display *display;
    Window window;
    GC     gc;
    char title[]      = "This is TITLE";
    char message[]    = "Hello New World!";
    char icon_title[] = "ICON!";
    unsigned long background;
    unsigned long foreground;

    display = XOpenDisplay(NULL);

    background = WhitePixel(display, 0);
    foreground = BlackPixel(display, 0);

    window = XCreateSimpleWindow(display,
                                 DefaultRootWindow(display),
                                 0, 0, 200, 100,
                                 0, 0, background);

    XSetStandardProperties(display, window, title, icon_title,
			   None, argv, argc, NULL);

    gc = XCreateGC(display, window, 0, 0);

    XSetBackground(display, gc, background);
    XSetForeground(display, gc, foreground);

    XMapRaised(display, window);

    XSelectInput(display, window,
		 ExposureMask |
		 KeyPressMask |
		 KeyReleaseMask |
		 ButtonPressMask |
		 ButtonReleaseMask );

    while (1){
	XEvent event;
	KeySym key;
	char string[10];
	char buf[100];

        XNextEvent(display, &event);

        switch (event.type){
          case Expose:
	    XDrawImageString(display, window, gc, 20, 20,
			     message, strlen(message));
            break;

	  case KeyPress:
	    XLookupString((XKeyEvent *)&event, string, sizeof(string), &key, NULL);
	    if ( string[0] == 'q' ){
		goto FINISH;
	    }
	    sprintf(buf, "KEY PRESS!   [%c]", string[0]);
	    XDrawImageString(display, window, gc, 20, 40,
			     buf, strlen(buf));
            break;

	  case KeyRelease:
	    XLookupString((XKeyEvent *)&event, string, sizeof(string), &key, NULL);
	    sprintf(buf, "KEY RELEASE! [%c]", string[0]);
	    XDrawImageString(display, window, gc, 20, 40,
			     buf, strlen(buf));
            break;

	  case ButtonPress:
	    sprintf(buf, "BUTTON PRESS!  %d", event.xbutton.button);
	    XDrawImageString(display, window, gc, 20, 60,
			     buf, strlen(buf));
            break;

	  case ButtonRelease:
	    sprintf(buf, "BUTTON RELASE! %d", event.xbutton.button);
	    XDrawImageString(display, window, gc, 20, 60,
			     buf, strlen(buf));
            break;
        }
    }

  FINISH:
    XCloseDisplay(display);
}
