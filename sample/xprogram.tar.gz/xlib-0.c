#include <X11/Xlib.h>
#include <X11/Xutil.h>

int main(int argc , char *argv[]){
    Display *display;
    Window window;
    GC     gc;
    char title[]   = "This is TITLE";
    char message[] = "Hello New World!";
    unsigned long background;
    unsigned long foreground;

    display = XOpenDisplay(NULL);

    background = WhitePixel(display,0);
    foreground = BlackPixel(display,0);

    window = XCreateSimpleWindow(display,
                                 DefaultRootWindow(display),
                                 0,0,
                                 200,100,
                                 0,0,background);
    XSetStandardProperties(display,window,title,title,
			   None,argv,argc,NULL);

    XMapRaised(display,window);
    XFlush(display);


    gc = XCreateGC(display,window,0,0);
    XFlush(display);

    XSetBackground(display,gc,background);
    XSetForeground(display,gc,foreground);
    XFlush(display);

    XDrawImageString(display,window,gc,20,50,message,strlen(message));
    XFlush(display);
    
    getchar();

    return 0;
}
